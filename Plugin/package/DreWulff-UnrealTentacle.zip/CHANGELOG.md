# v1.0.3
- Updated for compatibility with v73
- Added functional spawn rate config
- Removed on-collision damage

# v1.0.2
- Fixed missing script because of naming error

# v1.0.1
- Fixed README title

# v1.0.0 (Released 17-03-2025)
- Initial release